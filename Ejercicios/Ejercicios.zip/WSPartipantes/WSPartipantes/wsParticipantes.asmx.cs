﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using WSPartipantes.modelos;

namespace WSPartipantes
{
    /// <summary>
    /// Summary description for wsParticipantes
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class wsParticipantes : System.Web.Services.WebService
    {

        [WebMethod]
        public string RetornarNombreParticipante(string Nombre)
        {
            string _RetornaNombre = string.Empty;
            try
            {
                _RetornaNombre = string.Format("Hola {0}, bienvenido a la capacitación de WebServcices",Nombre);
            }
            catch (Exception ex)
            {

            }
            return _RetornaNombre;
        }

        [WebMethod]
        public Participante ObtenerParticipante()
        {
            Participante _Participante = new Participante();
            Puesto _Puesto = new Puesto();
            try
            {
                _Participante.Codigo = 1;
                _Participante.Nombre = "José Fernando";
                _Participante.Apellido = "Ramos";
                _Participante.NumeroIdentidad = "0801-1986-13914";
                _Participante.CorreoElectronico = "fernando.ramos@bi-dss-com";
                _Participante.FechaNacimiento = DateTime.Now;
                _Participante.Genero = "Masculino";

                _Puesto.Codigo = 1;
                _Puesto.NombrePuesto = "Analista Programdor";
                _Participante.Puesto = _Puesto;

            }
            catch (Exception ex)
            {
            }
            return _Participante;
        }

        [WebMethod]
        public List<Participante> ListadoParticipantes()
        {
            List<Participante> _Listado = new List<Participante>();
            try
            {
                Participante _Participante = new Participante();
                _Participante.Codigo = 1;
                _Participante.Nombre = "José Fernando";
                _Participante.Apellido = "Ramos";
                _Participante.NumeroIdentidad = "0801-1986-13914";
                _Participante.CorreoElectronico = "fernando.ramos@bi-dss-com";
                _Participante.FechaNacimiento = DateTime.Now;
                _Participante.Genero = "Masculino";
                _Listado.Add(_Participante);

                Participante _Participante2 = new Participante();
                _Participante2.Codigo = 1;
                _Participante2.Nombre = "Diego Fernando";
                _Participante2.Apellido = "Ramos";
                _Participante2.NumeroIdentidad = "0801-2010-13914";
                _Participante2.CorreoElectronico = "diego.ramos@gmail.com";
                _Participante2.FechaNacimiento = DateTime.Now;
                _Participante2.Genero = "Masculino";
                _Listado.Add(_Participante2);

            }
            catch (Exception ex)
            {
            }
            return _Listado;
        }
    }
}
