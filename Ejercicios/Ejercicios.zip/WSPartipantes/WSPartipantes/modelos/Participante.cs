﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSPartipantes.modelos
{
    public class Participante
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string NumeroIdentidad { get; set; }
        public string CorreoElectronico { get; set; }
        public string Genero { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public Puesto Puesto { get; set; }
    }
}