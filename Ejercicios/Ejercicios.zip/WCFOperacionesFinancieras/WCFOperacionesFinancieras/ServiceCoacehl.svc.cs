﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WCFOperacionesFinancieras.Modelos;

namespace WCFOperacionesFinancieras
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class ServiceCoacehl : IServiceCoacehl
    {
        
        public Cliente ObtenerCliente(string codigoAfiliado)
        {
            Cliente _Cliente = new Cliente();
            try
            {
                _Cliente.CodigoAfiliado = "0001";
                _Cliente.NombreAfiliado = "José Fernando Ramos";
                _Cliente.NumeroIdentidad = "0801-1986-13914";
                _Cliente.CorreoElectronico = "fernando.ramos@bi-dss.com";
            }
            catch (Exception ex)
            {
            }
            return _Cliente;
        }

        public Cuenta ObtenerCuenta(string numeroCuenta)
        {
            Cuenta _Cuenta = new Cuenta();
            try
            {
                _Cuenta.NumeroCuenta = "21-000-000-1";
                _Cuenta.TipoCuenta = TipoCuenta.Ahorros;
                _Cuenta.SaldoDisponible = (decimal)12500.20;
                _Cuenta.SaldoPignorado = (decimal)0.00;
                _Cuenta.Cliente = ObtenerCliente("0001");
            }
            catch (Exception ex)
            {
            }
            return _Cuenta;
        }

        public Respuesta OperacionFinanciera(Cuenta cuenta, Operacion operacion)
        {
            /*
            Validaciones:
            1. Venga el objeto de cuenta.
            2. Venga el objeto de operacion.
            3. Para cualquier operación, validar el monto de transacción sea mayor a 0.00
            4. TipoOperacion es Retiro, valida el saldo disponible de la cuenta sea
               mayor al monto de la operación.
            5. Si las validaciones se cumplen, retornar la respuesta:
              Codigo = 0: Correcto, <> 0, Error con su mensaje
             Si es correcto, devolver el número de autorización.
            */
            Respuesta _Respuesta = new Respuesta();
            try
            {
                //1. Viene la cuenta
                if (cuenta == null)
                {
                    _Respuesta.CodigoRespuesta = 1;
                    _Respuesta.MensajeRespuesta = "La cuenta es obligatoria";
                    return _Respuesta;
                }
                //2. Viene la operacion
                if (operacion == null)
                {
                    _Respuesta.CodigoRespuesta = 1;
                    _Respuesta.MensajeRespuesta = "La operacion es obligatoria";
                    return _Respuesta;
                }
                //3. Para cualquier operación, validar el monto de transacción sea mayor a 0.00
                if (operacion.MontoOperacion == 0)
                {
                    _Respuesta.CodigoRespuesta = 1;
                    _Respuesta.MensajeRespuesta = "El monto de la operacion debe ser mayor a 0.00";
                    return _Respuesta;
                }
                //4. TipoOperacion es Retiro, valida el saldo disponible de la cuenta sea
               //    mayor al monto de la operación.
                switch (operacion.TipoOperacion)
                {
                    case TipoOperacion.Retiro:
                        if (cuenta.SaldoDisponible < operacion.MontoOperacion)
                        {
                            _Respuesta.CodigoRespuesta = 1;
                            _Respuesta.MensajeRespuesta = "No tiene fondos disponibles para operar el retiro";
                            return _Respuesta;
                        }
                        break;
                }

                //5. Todo bien
                _Respuesta.CodigoRespuesta = 0;
                _Respuesta.MensajeRespuesta = "La operación se ha realizado correctamente";
                _Respuesta.NumeroAutorizacion = 1872182;
            }
            catch (Exception ex)
            {
                _Respuesta.CodigoRespuesta = 1;
                _Respuesta.MensajeRespuesta = ex.Message;
            }
            return _Respuesta;

        }
    }
}
