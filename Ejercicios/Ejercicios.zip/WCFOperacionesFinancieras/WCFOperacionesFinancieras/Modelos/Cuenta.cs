﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WCFOperacionesFinancieras.Modelos
{
    public enum TipoCuenta{
        Ninguno = 0,
        Ahorros = 1,
        Aportaciones = 2,
        Prestamo = 3,
        Navidenio = 4
    }

    [DataContract]
    public class Cuenta
    {
        [DataMember]
        public string NumeroCuenta { get; set; }
        [DataMember]
        public TipoCuenta TipoCuenta { get; set; }
        [DataMember]
        public decimal SaldoDisponible { get; set; }
        [DataMember]
        public decimal SaldoPignorado { get; set; }
        [DataMember]
        public Cliente Cliente { get; set; }
    }
}