﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WCFOperacionesFinancieras.Modelos
{
    [DataContract]
    public class Cliente
    {
        [DataMember]
        public string CodigoAfiliado { get; set; }
        [DataMember]
        public string NombreAfiliado { get; set; }
        [DataMember]
        public string NumeroIdentidad { get; set; }
        [DataMember]
        public string CorreoElectronico { get; set; }

    }
}