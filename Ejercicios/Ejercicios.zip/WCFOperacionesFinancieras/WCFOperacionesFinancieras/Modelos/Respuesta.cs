﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WCFOperacionesFinancieras.Modelos
{
    [DataContract]
    public class Respuesta
    {
        [DataMember]
        public int CodigoRespuesta { get; set; }
        [DataMember]
        public string MensajeRespuesta { get; set; }
        [DataMember]
        public int NumeroAutorizacion { get; set; }
    }
}