﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WCFOperacionesFinancieras.Modelos
{
    public enum TipoOperacion
    {
        Ninguno = 0,
        Deposito = 1,
        Retiro = 2,
        PagoPrestamo= 3
    }
    [DataContract]
    public class Operacion
    {
        [DataMember]
        public Cuenta Cuenta { get; set; }
        [DataMember]
        public Cliente Cliente { get; set; }
        [DataMember]
        public TipoOperacion TipoOperacion { get; set; }
        [DataMember]
        public decimal MontoOperacion { get; set; }
    }
}