﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestCoacehl.Models
{
    public class Cliente
    {
        public string CodigoAfiliado { get; set; }
        public string NombreAfiliado { get; set; }
        public string NumeroIdentidad { get; set; }

    }
}