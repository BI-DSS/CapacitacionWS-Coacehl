﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RestCoacehl.Models;

namespace RestCoacehl.Controllers
{
    [RoutePrefix("api/cliente")]
    public class ClienteController : ApiController
    {

        [HttpGet]
        [Route("obtenerCliente")]
        public IHttpActionResult ObtenerCliente(string codigo)
        {
            Cliente _Cliente = new Cliente();
            try
            {
                _Cliente.CodigoAfiliado = "0001";
                _Cliente.NombreAfiliado = "José Fernando Ramos";
                _Cliente.NumeroIdentidad = "0801-1986-13914";
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
            return Ok(_Cliente);
        }

        [HttpGet]
        [Route("listadoClientes")]
        public IHttpActionResult ListadoClientes()
        {
            List<Cliente> _Listado = new List<Cliente>();
            try
            {
                Cliente _Cliente1 = new Cliente();
                _Cliente1.CodigoAfiliado = "0001";
                _Cliente1.NombreAfiliado = "José Fernando Ramos";
                _Cliente1.NumeroIdentidad = "0801-1986-13914";
                _Listado.Add(_Cliente1);

                Cliente _Cliente2 = new Cliente();
                _Cliente2.CodigoAfiliado = "0002";
                _Cliente2.NombreAfiliado = "Diego Fernando Ramos";
                _Cliente2.NumeroIdentidad = "0801-2010-13914";
                _Listado.Add(_Cliente2);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
            return Ok(_Listado);
        }
    }
}
